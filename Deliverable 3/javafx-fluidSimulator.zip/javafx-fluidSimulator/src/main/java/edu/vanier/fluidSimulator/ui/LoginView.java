package edu.vanier.fluidSimulator.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.control.Alert.AlertType;

public class LoginView extends Pane {

    Label title = new Label("Buoyancy Simulator\nBy: Brendon, Eric, Kamran, and Hamza");
    Text user = new Text("Username:");
    TextField userTextField = new TextField();
    Text pass = new Text("Password:");
    PasswordField passTextField = new PasswordField();
    Button loginbtn = new Button("Login");
    Button registerButton = new Button("Register");

    private Member memberHandler;

    public LoginView(Member handler) {
        this.memberHandler = handler;
        
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        //css stuff
        grid.getStyleClass().add("grid-pane");
        title.getStyleClass().add("title");
        user.getStyleClass().add("text");
        pass.getStyleClass().add("text");
        userTextField.getStyleClass().add("text-field");
        passTextField.getStyleClass().add("password-field");
        loginbtn.getStyleClass().add("button");
        registerButton.getStyleClass().add("button");
        this.getStyleClass().add("root");

        //css
        this.getStylesheets().add(getClass().getResource("/DarkLoginView-styles.css").toExternalForm());

        title.setFont(new Font(20));

        grid.add(title, 0, 0, 2, 1);
        grid.add(user, 0, 1);
        grid.add(userTextField, 1, 1);
        grid.add(pass, 0, 2);
        grid.add(passTextField, 1, 2);

        //prompt stuff
        passTextField.setPromptText("Password");
        userTextField.setPromptText("Username");

        // Button container
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().addAll(loginbtn, registerButton);
        grid.add(buttonBox, 0, 3, 2, 1);

        this.getChildren().add(grid);

        //switch scenes, buttons
        loginbtn.setOnAction(e -> handleLogin());
        registerButton.setOnAction(e -> handleRegister());
    }

    private void handleLogin() {
        String username = userTextField.getText().trim();
        String password = passTextField.getText().trim();

        //alert
        if (username.isEmpty() || password.isEmpty()) {
            showAlert(AlertType.ERROR, "Login Failed", "Please enter both username and password.");
            return;
        }

        //check if it exists and alert
        if (memberHandler.isValidLogin(username, password)) {
            showAlert(AlertType.INFORMATION, "Login Successful", "Welcome, " + username + "!");
        } else {
            showAlert(AlertType.ERROR, "Login Failed", "Invalid username or password.");
        }
    }

    private void handleRegister() {
        String username = userTextField.getText().trim();
        String password = passTextField.getText().trim();

        //alert
        if (username.isEmpty() || password.isEmpty()) {
            showAlert(AlertType.ERROR, "Registration Failed", "Please enter both username and password.");
            return;
        }

        //alert + run register method
        if (memberHandler.create(username, password)) {
            showAlert(AlertType.INFORMATION, "Registration Successful",
                    "User " + username + " has been registered successfully.");
        } else {
            showAlert(AlertType.ERROR, "Registration Failed", "Username already exists.");
        }
    }

    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
