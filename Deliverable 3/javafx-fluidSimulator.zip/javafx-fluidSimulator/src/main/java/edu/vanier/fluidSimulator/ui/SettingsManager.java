package edu.vanier.fluidSimulator.ui;

import com.google.gson.Gson;
import edu.vanier.fluidSimulator.model.Particle.LiquidType;
import edu.vanier.fluidSimulator.model.SimulationObject.SimulationObjectType;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class SettingsManager {

    private static final String SETTINGS_FILE = "settings.json";

    public static class Settings {
        public double fontSize = 15;
        public String language = "English";

        // simulation params
        public double mass = 5.5;
        public double volume = 5.5;
        public boolean gravity = false;
        public boolean typeInteraction = false;
        public boolean forceValues = false;
        public LiquidType liquidType = LiquidType.WATER;
        public SimulationObjectType objectType = SimulationObjectType.CUSTOM;
    }

    public static void save(Settings settings) {
        try (FileWriter writer = new FileWriter(SETTINGS_FILE)) {
            new Gson().toJson(settings, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Settings load() {
        try (FileReader reader = new FileReader(SETTINGS_FILE)) {
            Settings s = new Gson().fromJson(reader, Settings.class);
            if (s == null || s.language == null || s.fontSize <= 0) throw new Exception();
            return s;
        } catch (Exception e) {
            System.out.println("Invalid or missing settings.json. Using defaults.");
            return new Settings();
        }
    }
}
