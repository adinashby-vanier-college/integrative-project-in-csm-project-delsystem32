package edu.vanier.fluidSimulator.ui;

import java.io.*;
import java.util.HashMap;
import java.util.Map;


//this is a handler class that has the logic for the login/register
//uses hashmaps and keys for the account/password
public class Member {
    
    private Map<String, String> users;
    private final String Accounts = "accounts.txt";

    // default cons
    public Member() {
        users = new HashMap<>();
        loadAccs();
    }
    
    private void loadAccs() {
        try (BufferedReader reader = new BufferedReader(new FileReader(Accounts))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", 2);
                if (parts.length == 2) {
                    users.put(parts[0], parts[1]);
                }
            }
        } catch (IOException e) {
            System.out.println("Account file not found.");
        }
    }
    
    private void saveAcc(String username, String password) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(Accounts, true))) {
            writer.write(username + "," + password);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error saving account: " + e.getMessage());
        }
    }
    
    public boolean isValidLogin(String username, String password) {
        return users.containsKey(username) && users.get(username).equals(password);
    }
    
    public boolean create(String username, String password) {
        if (users.containsKey(username)) {
            return false;
        }

        users.put(username, password);
        saveAcc(username, password);
        return true;
    }
    
}
