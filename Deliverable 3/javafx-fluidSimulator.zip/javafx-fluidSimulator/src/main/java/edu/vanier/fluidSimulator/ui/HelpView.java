package edu.vanier.fluidSimulator.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import java.util.ResourceBundle;
import java.util.function.Consumer;

public class HelpView extends Pane {

    private final Label title = new Label();
    private final Text txt = new Text("");
    final Button backbutton = new Button();

    private Consumer<Double> onFontSizeChange;

    public HelpView() {
        title.setUnderline(true);
        title.setFont(new Font(20));

        txt.getStyleClass().add("txt");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        grid.add(title, 0, 0, 2, 1);
        grid.add(txt, 0, 1);
        ScrollPane scrollPane = new ScrollPane(txt);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefViewportWidth(650);
        scrollPane.setPrefViewportHeight(400);
        scrollPane.setPadding(new Insets(10));

        grid.add(scrollPane, 0, 1);

        HBox hb = new HBox(10);
        hb.setAlignment(Pos.BOTTOM_RIGHT);
        hb.getChildren().add(backbutton);

        grid.add(hb, 0, 6);

        this.getChildren().add(grid);

        updateLanguage(ResourceBundle.getBundle("lang.messages"));
    }

    public void updateFontSize(double size) {
        Font font = new Font(size);
        title.setFont(font);
        txt.setFont(font);
        backbutton.setFont(font);
        if (onFontSizeChange != null) {
            onFontSizeChange.accept(size);
        }
    }

    public void updateLanguage(ResourceBundle bundle) {
        title.setText(bundle.getString("help_title"));
        backbutton.setText(bundle.getString("back"));
        txt.setText(bundle.getString("help_text"));
    }

    public void setOnFontSizeChange(Consumer<Double> listener) {
        this.onFontSizeChange = listener;
    }
}
