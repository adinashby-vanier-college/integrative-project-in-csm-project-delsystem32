package edu.vanier.fluidSimulator.model;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;

public class ForceArrow extends Group {
    private final Line line;
    private final Polygon arrowHead;

    public enum Direction {
        UP, DOWN
    }

    public ForceArrow(Color color,  Direction direction) {
        line = new Line();
        line.setStroke(color);
        line.setStrokeWidth(5);

        arrowHead = new Polygon();
        if (direction == Direction.UP) {
            arrowHead.getPoints().addAll(-5.0, 0.0, 0.0, -10.0, 5.0, 0.0); // Points upward
        } else {
            arrowHead.getPoints().addAll(-5.0, 0.0, 0.0, 10.0, 5.0, 0.0); // Points downward
        }
        arrowHead.setFill(color);

        this.getChildren().addAll(line, arrowHead);
    }

    public void update(double startX, double startY, double endX, double endY) {
        line.setStartX(startX);
        line.setStartY(startY);
        line.setEndX(endX);
        line.setEndY(endY);
        arrowHead.setTranslateX(endX);
        arrowHead.setTranslateY(endY);
        this.toFront();
    }
}
