package edu.vanier.fluidSimulator.physics;

import java.util.ArrayList;
import java.util.List;
import edu.vanier.fluidSimulator.model.Particle;

/**
 * SpatialGrid Class used to reduce load on memory when running application with many simulating particles.
 * Divides the simulation container into a grid of cells. Much better than using O(n²) process.
 *
 * @author Hamza
 */
public class SpatialGrid {
    private int cols, rows;
    private double cellSize;
    private List<Particle>[][] grid;

    @SuppressWarnings("unchecked") //suppress warning (for now)
    public SpatialGrid(double width, double height, double cellSize) {
        this.cellSize = cellSize;
        cols = (int) Math.ceil(width / cellSize);
        rows = (int) Math.ceil(height / cellSize);
        grid = new ArrayList[cols][rows];
        for (int i = 0; i < cols; i++) {
            for (int j = 0; j < rows; j++) {
                grid[i][j] = new ArrayList<>();
            }
        }
    }

    public void clear() {
        for (int i = 0; i < cols; i++) {
            for (int j = 0; j < rows; j++) {
                grid[i][j].clear();
            }
        }
    }

    public void add(Particle p) {
        double x = p.getLayoutX() + p.getTranslateX();
        double y = p.getLayoutY() + p.getTranslateY();
        int col = (int)(x / cellSize);
        int row = (int)(y / cellSize);
        if(col >= 0 && col < cols && row >= 0 && row < rows)
            grid[col][row].add(p);
    }

    public List<Particle> getNeighbors(Particle p) {
        List<Particle> neighbors = new ArrayList<>();
        double x = p.getLayoutX() + p.getTranslateX();
        double y = p.getLayoutY() + p.getTranslateY();
        int col = (int)(x / cellSize);
        int row = (int)(y / cellSize);
        for (int i = col - 1; i <= col + 1; i++) {
            for (int j = row - 1; j <= row + 1; j++) {
                if(i >= 0 && i < cols && j >= 0 && j < rows) {
                    neighbors.addAll(grid[i][j]);
                }
            }
        }
        return neighbors;
    }
}
