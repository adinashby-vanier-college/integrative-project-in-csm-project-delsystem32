package edu.vanier.fluidSimulator.ui;

import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class WaterSimApp extends Application {

    private Stage helpStage;
    private Stage optionsStage;
    private Scene mainScene;
    private Scene loginScene;
    private Scene helpScene;
    private Scene optionsScene;
    private Stage primaryStage;
    private Member memberHandler = new Member();

    @Override
    public void start(Stage stage) {
        try {
            primaryStage = stage;

            LoginView login = new LoginView(memberHandler);
            HelpView help = new HelpView();
            MainSceneView mainview = new MainSceneView();
            OptionsView options = new OptionsView(mainview, help);

            mainScene = new Scene(mainview, 950, 650);
            loginScene = new Scene(login, 400, 220);
            helpScene = new Scene(help);
            optionsScene = new Scene(options, 700, 400);

            stage.setTitle("Buoyancy Simulator");
            stage.setScene(loginScene);
            stage.setResizable(false);
            stage.show();
            stage.centerOnScreen();

            helpStage = new Stage();
            helpStage.setTitle("Help");
            helpStage.setScene(helpScene);
            helpStage.initOwner(primaryStage);
            helpStage.initModality(Modality.WINDOW_MODAL);
            helpStage.setOnCloseRequest(e -> helpStage.hide());
            helpStage.setOnShown(e -> helpStage.centerOnScreen());

            help.setOnFontSizeChange(size -> {
                helpStage.sizeToScene();
            });

            optionsStage = new Stage();
            optionsStage.setTitle("Options");
            optionsStage.setScene(optionsScene);
            optionsStage.initOwner(primaryStage);
            optionsStage.initModality(Modality.WINDOW_MODAL);
            optionsStage.setOnCloseRequest(e -> optionsStage.hide());
            optionsStage.setOnShown(e -> optionsStage.centerOnScreen());

            login.loginbtn.setOnAction(e -> {
                String username = login.userTextField.getText().trim();
                String password = login.passTextField.getText().trim();

                if (memberHandler.isValidLogin(username, password)) {
                    primaryStage.setScene(mainScene);
                    primaryStage.centerOnScreen();
                } else {
                    showAlert(AlertType.ERROR, "Login Failed", "Invalid username or password.");
                }
            });

            mainview.logoutMenuItem.setOnAction(e -> {
                primaryStage.setScene(loginScene);
                primaryStage.centerOnScreen();
            });

            mainview.exitMenuItem.setOnAction(e -> Platform.exit());

            mainview.helpMenuItem.setOnAction(e -> {
                if (!helpStage.isShowing()) {
                    helpStage.show();
                } else {
                    helpStage.toFront();
                }
            });

            mainview.optionsMenuItem.setOnAction(e -> {
                if (!optionsStage.isShowing()) {
                    optionsStage.show();
                } else {
                    optionsStage.toFront();
                }
            });

            help.backbutton.setOnAction(e -> helpStage.hide());
            options.backbutton.setOnAction(e -> optionsStage.hide());

            options.light.setOnAction(e -> {
                mainScene.getStylesheets().clear();
                optionsScene.getStylesheets().clear();
                helpScene.getStylesheets().clear();
            });

            options.dark.setOnAction(e -> {
                mainScene.getStylesheets().clear();
                mainScene.getStylesheets().add(getClass().getResource("/DarkMode.css").toExternalForm());
                optionsScene.getStylesheets().add(getClass().getResource("/DarkMode.css").toExternalForm());
                helpScene.getStylesheets().add(getClass().getResource("/DarkMode.css").toExternalForm());
            });

        } catch (Exception ex) {
            Logger.getLogger(WaterSimApp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
