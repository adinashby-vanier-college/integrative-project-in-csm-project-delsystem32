package edu.vanier.fluidSimulator.ui;

import com.google.gson.Gson;
import edu.vanier.fluidSimulator.ui.SettingsManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;

import java.util.Locale;
import java.util.ResourceBundle;

public class OptionsView extends Pane {

    private final MainSceneView mainSceneView;
    private final HelpView helpView;

    Label title = new Label();
    Label scheme = new Label();
    Button light = new Button();
    Button dark = new Button();
    Label language = new Label();

    ObservableList<String> languages = FXCollections.observableArrayList("English", "French", "Spanish");
    ComboBox<String> cb = new ComboBox<>(languages);

    Label fontsize = new Label();
    Slider fontSlider = new Slider(10, 20, 15);
    Button backbutton = new Button();
    Button saveButton = new Button();
    Button loadButton = new Button();

    private ResourceBundle bundle;

    public OptionsView(MainSceneView mainSceneView, HelpView helpView) {
        this.mainSceneView = mainSceneView;
        this.helpView = helpView;

        // Load previously saved settings
        SettingsManager.Settings settings = SettingsManager.load();
        fontSlider.setValue(settings.fontSize);
        cb.setValue(settings.language);

        Locale locale = switch (settings.language) {
            case "French" -> Locale.FRENCH;
            case "Spanish" -> new Locale("es");
            default -> Locale.ENGLISH;
        };
        bundle = ResourceBundle.getBundle("lang.messages", locale);
        updateTexts(bundle);
        mainSceneView.updateFontSize(settings.fontSize);
        helpView.updateFontSize(settings.fontSize);
        mainSceneView.updateLanguage(bundle);
        helpView.updateLanguage(bundle);

        // Apply saved simulation parameters
        mainSceneView.setMass(settings.mass);
        mainSceneView.setVolume(settings.volume);
        mainSceneView.setGravityEnabled(settings.gravity);
        mainSceneView.setTypeInteractionEnabled(settings.typeInteraction);
        mainSceneView.setForceValuesEnabled(settings.forceValues);
        mainSceneView.setLiquidType(settings.liquidType);
        mainSceneView.setObjectType(settings.objectType);

        title.setUnderline(true);
        title.setFont(new Font(15));

        scheme.setUnderline(true);
        light.setManaged(true);

        language.setUnderline(true);
        fontsize.setUnderline(true);

        fontSlider.setShowTickMarks(true);
        fontSlider.setShowTickLabels(true);
        fontSlider.setMajorTickUnit(10);
        fontSlider.setMinorTickCount(10);
        fontSlider.setSnapToTicks(true);

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25));

        grid.add(title, 0, 0, 2, 1);
        grid.add(scheme, 0, 1);
        grid.add(light, 1, 1);
        grid.add(dark, 2, 1);
        grid.add(language, 0, 3);
        grid.add(cb, 1, 3);
        grid.add(fontsize, 0, 5);
        grid.add(fontSlider, 1, 5);
        grid.add(saveButton, 0, 6);
        grid.add(loadButton, 1, 6);

        HBox hb = new HBox(10);
        hb.setAlignment(Pos.BOTTOM_RIGHT);
        hb.getChildren().add(backbutton);
        grid.add(hb, 0, 7, 3, 1);

        this.getChildren().add(grid);

        fontSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            double fontSize = newValue.doubleValue();

            title.setFont(new Font(fontSize));
            scheme.setFont(new Font(fontSize));
            light.setFont(new Font(fontSize));
            dark.setFont(new Font(fontSize));
            language.setFont(new Font(fontSize));
            cb.setStyle("-fx-font-size: " + fontSize + "px;");
            fontsize.setFont(new Font(fontSize));
            backbutton.setFont(new Font(fontSize));

            mainSceneView.updateFontSize(fontSize);
            helpView.updateFontSize(fontSize);
        });

        cb.setOnAction(e -> {
            String selected = cb.getValue();
            Locale selectedLocale = switch (selected) {
                case "French" -> Locale.FRENCH;
                case "Spanish" -> new Locale("es");
                default -> Locale.ENGLISH;
            };
            bundle = ResourceBundle.getBundle("lang.messages", selectedLocale);
            updateTexts(bundle);
            mainSceneView.updateLanguage(bundle);
            helpView.updateLanguage(bundle);
        });

        saveButton.setOnAction(e -> {
            SettingsManager.Settings s = new SettingsManager.Settings();
            s.fontSize = fontSlider.getValue();
            s.language = cb.getValue();
            s.mass = mainSceneView.getMass();
            s.volume = mainSceneView.getVolume();
            s.gravity = mainSceneView.isGravityEnabled();
            s.typeInteraction = mainSceneView.isTypeInteractionEnabled();
            s.forceValues = mainSceneView.isForceValuesEnabled();
            s.liquidType = mainSceneView.getCurrentLiquidType();
            s.objectType = mainSceneView.getCurrentObjectType();
            SettingsManager.save(s);
        });

        loadButton.setOnAction(e -> {
            SettingsManager.Settings s = SettingsManager.load();
            fontSlider.setValue(s.fontSize);
            cb.setValue(s.language);

            mainSceneView.setMass(s.mass);
            mainSceneView.setVolume(s.volume);
            mainSceneView.setGravityEnabled(s.gravity);
            mainSceneView.setTypeInteractionEnabled(s.typeInteraction);
            mainSceneView.setForceValuesEnabled(s.forceValues);
            mainSceneView.setLiquidType(s.liquidType);
            mainSceneView.setObjectType(s.objectType);
        });
    }

    private void updateTexts(ResourceBundle bundle) {
        title.setText(bundle.getString("options"));
        scheme.setText(bundle.getString("colour_scheme"));
        light.setText(bundle.getString("light"));
        dark.setText(bundle.getString("dark"));
        language.setText(bundle.getString("language"));
        fontsize.setText(bundle.getString("font_size"));
        backbutton.setText(bundle.getString("back"));
        saveButton.setText(bundle.getString("save"));
        loadButton.setText(bundle.getString("load"));
    }
}
