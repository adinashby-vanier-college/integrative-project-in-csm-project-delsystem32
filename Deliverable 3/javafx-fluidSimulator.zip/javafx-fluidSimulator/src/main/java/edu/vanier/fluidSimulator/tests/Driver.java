package edu.vanier.fluidSimulator.tests;

import edu.vanier.fluidSimulator.model.Particle;
import edu.vanier.fluidSimulator.model.SimulationObject;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.List;

public class Driver {

    public static void main(String[] args) {
        System.out.println("=== Running Simulation Tests ===");

        Pane testPane = new Pane();

        testMassVolume(testPane);

        testGravity(testPane);

        testBuoyancy(testPane);

        testDensity(testPane);

        testWallCollision(testPane);
    }

    private static void testMassVolume(Pane pane) {
        System.out.println("\n--- Test: Mass and Volume Setup ---");
        SimulationObject obj = new SimulationObject(pane, 10, 10, SimulationObject.SimulationObjectType.CUSTOM, Color.BLACK);
        System.out.println("Mass = " + obj.getMass());
        System.out.println("Volume = " + obj.getVolume());
    }

    private static void testGravity(Pane pane) {
        System.out.println("\n--- Test: Gravity Application ---");
        SimulationObject obj = new SimulationObject(pane, 5, 5, SimulationObject.SimulationObjectType.CUSTOM, Color.BLACK);
        obj.applyGravity();
        System.out.println("Gravitational Force: " + obj.getGravitationalForce());
        obj.updatePhysics(0.016); //simulate one frame
        obj.updatePosition();
        System.out.println("New Position: (" + obj.getTranslateX() + ", " + obj.getTranslateY() + ")");
    }

    private static void testBuoyancy(Pane pane) {
        System.out.println("\n--- Test: Buoyancy ---");
        SimulationObject obj = new SimulationObject(pane, 4, 4, SimulationObject.SimulationObjectType.CUSTOM, Color.BLACK);

        List<Particle> particles = new ArrayList<>();
        Particle waterParticle = new Particle(300, 300, 6, Particle.LiquidType.WATER, Color.BLUE);
        waterParticle.setTranslateX(obj.getLayoutX());
        waterParticle.setTranslateY(obj.getLayoutY());
        particles.add(waterParticle);

        obj.applyBuoyancy(300, particles);
        System.out.println("Buoyancy Force (water touching): " + obj.getBuoyancyForce());

        obj.applyBuoyancy(300, new ArrayList<>());
        System.out.println("Buoyancy Force (no contact): " + obj.getBuoyancyForce());
    }

    private static void testDensity(Pane pane) {
        System.out.println("\n--- Test: Object Density ---");
        SimulationObject obj = new SimulationObject(pane, 8, 4, SimulationObject.SimulationObjectType.CUSTOM, Color.BLACK);
        System.out.printf("Expected Density = %.2f\n", obj.getMass() / obj.getVolume());
        System.out.printf("Reported Density = %.2f\n", obj.getDensity());
    }

    private static void testWallCollision(Pane pane) {
        System.out.println("\n--- Test: Wall Collision ---");
        pane.setPrefSize(500, 500);
        SimulationObject obj = new SimulationObject(pane, 5, 5, SimulationObject.SimulationObjectType.CUSTOM, Color.BLACK);
        obj.setTranslateX(490); //near right wall
        obj.setTranslateY(490); //near bottom wall

        obj.setVelocity(50, 50);
        obj.handleWallCollisions(false);
        System.out.println("Post-collision Translate: (" + obj.getTranslateX() + ", " + obj.getTranslateY() + ")");
        System.out.println("Velocity affected by bounce.");
    }
}
