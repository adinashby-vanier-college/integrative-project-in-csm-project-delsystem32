package edu.vanier.fluidSimulator.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

/**
 *
 * @author bdmmc
 */
public class HelpView extends Pane{
    
    Label title = new Label("Help Page");
    Text txt = new Text("""
                        There will be text here talking about how to run the program
                        It will list the functions of all the different parts of the program
                        As well as the different features available
                        and how to operate them""");
    Button backbutton = new Button("Back to main screen"); 
    
    HelpView() {
        
        title.underlineProperty().set(true);
        title.setFont(new Font(20));
        
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));
        
        grid.add(title, 0, 0, 2, 1);
        grid.add(txt, 0, 1);
        
        HBox hb = new HBox(10);
        hb.setAlignment(Pos.BOTTOM_RIGHT);
        hb.getChildren().add(backbutton);
        
        grid.add(hb, 0, 13);
        
        this.getChildren().add(grid);
        
    }
}
