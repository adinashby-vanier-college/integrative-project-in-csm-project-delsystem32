package edu.vanier.fluidSimulator.model;

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

/**
 * Particle class that represents a liquid particle. It now includes a liquid type so that type‐specific interactions
 * can be applied when particles of different liquids touch.
 *
 * @author Hamza
 */
public class Particle extends Circle {

    private double velocityX;
    private double velocityY;
    private final LiquidType type;

    public static final double GRAVITY = 0.2;
    private static final double WALL_DAMPING = 0.7;

    public enum LiquidType {
        WATER(1.0, 1.5),
        OIL(0.8, 1.2),
        HONEY(1.4, 40);

        private final double density;
        private final double dragCoefficient;

        LiquidType(double density, double dragCoefficient) {
            this.density = density;
            this.dragCoefficient = dragCoefficient;
        }
        public double getDensity() {
            return density;
        }
        public double getDragCoefficient() {
            return dragCoefficient;
        }
    }

    public Particle(double x, double y, double radius, LiquidType type, Color color) {
        super(radius);
        this.type = type;
        this.velocityX = (Math.random() - 0.5) * 2;
        this.velocityY = (Math.random() - 0.5) * 2;
        this.setFill(color);
        this.setOpacity(0.6);
        setLayoutX(x);
        setLayoutY(y);
        setTranslateX(0);
        setTranslateY(0);
    }

    public LiquidType getLiquidType() {
        return type;
    }

    public void applyGravity() {
        velocityY += GRAVITY;
    }

    public void checkWallCollisions(double width, double height) {
        double radius = getRadius();
        double totalX = getLayoutX() + getTranslateX();
        double totalY = getLayoutY() + getTranslateY();

        //horizontal walls
        double nextX = totalX + velocityX;
        if (nextX < radius) {
            velocityX = -velocityX * WALL_DAMPING;
            setTranslateX(radius - getLayoutX());
        } else if (nextX > width - radius) {
            velocityX = -velocityX * WALL_DAMPING;
            setTranslateX(width - radius - getLayoutX());
        }

        //vertical walls
        double nextY = totalY + velocityY;
        if (nextY < radius) {
            velocityY = -velocityY * WALL_DAMPING;
            setTranslateY(radius - getLayoutY());
        } else if (nextY > height - radius) {
            velocityY = -velocityY * WALL_DAMPING;
            setTranslateY(height - radius - getLayoutY());
        }
    }

    public void applyCohesion(double targetX, double targetY, double factor) {
        double currentX = getLayoutX() + getTranslateX();
        double currentY = getLayoutY() + getTranslateY();
        velocityX += (targetX - currentX) * factor;
        velocityY += (targetY - currentY) * factor;
    }

    public void updatePosition() {
        setTranslateX(getTranslateX() + velocityX);
        setTranslateY(getTranslateY() + velocityY);
    }

    public double getVelocityX() {
        return velocityX;
    }

    public double getVelocityY() {
        return velocityY;
    }

    public void addVelocity(double dx, double dy) {
        velocityX += dx;
        velocityY += dy;
    }
}
