package edu.vanier.fluidSimulator.ui;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class WaterSimApp extends Application {

    private Stage helpStage;
    private Stage optionsStage;
    private Scene mainScene;
    private Scene loginScene;
    private Stage primaryStage;
    private Member memberHandler = new Member();

    @Override
    public void start(Stage stage) {
        try {
            primaryStage = stage;

            LoginView login = new LoginView();
            HelpView help = new HelpView();
            OptionsView options = new OptionsView();
            MainSceneView mainview = new MainSceneView();

            mainScene = new Scene(mainview, 950, 650);
            loginScene = new Scene(login, 400, 220);
            Scene helpScene = new Scene(help, 400, 300);
            Scene optionsScene = new Scene(options, 700, 400);

            stage.setTitle("Buoyancy Simulator");
            stage.setScene(loginScene);
            stage.setResizable(false);
            stage.show();
            stage.centerOnScreen();

            helpStage = new Stage();
            helpStage.setTitle("Help");
            helpStage.setScene(helpScene);
            helpStage.initOwner(primaryStage);
            helpStage.initModality(Modality.WINDOW_MODAL);
            helpStage.setOnCloseRequest(e -> helpStage.hide());
            helpStage.setOnShown(e -> helpStage.centerOnScreen());

            optionsStage = new Stage();
            optionsStage.setTitle("Options");
            optionsStage.setScene(optionsScene);
            optionsStage.initOwner(primaryStage);
            optionsStage.initModality(Modality.WINDOW_MODAL);
            optionsStage.setOnCloseRequest(e -> optionsStage.hide());
            optionsStage.setOnShown(e -> optionsStage.centerOnScreen());

            // Log in
            login.loginbtn.setOnAction(e -> {
                String username = login.userTextField.getText().trim();
                String password = login.passTextField.getText().trim();
                Member user = new Member(username, password, "");

                if (memberHandler.isMemberExist(user)) {
                    primaryStage.setScene(mainScene);
                    primaryStage.centerOnScreen();
                } else {
                    showAlert(AlertType.ERROR, "Login Failed", "Invalid username or password.");
                }
            });

            // Log out
            mainview.logoutMenuItem.setOnAction(e -> {
                primaryStage.setScene(loginScene);
                primaryStage.centerOnScreen();
            });

            // Exit
            mainview.exitMenuItem.setOnAction(e -> Platform.exit());

            // Help
            mainview.helpMenuItem.setOnAction(e -> {
                if (!helpStage.isShowing()) {
                    helpStage.show();
                } else {
                    helpStage.toFront();
                }
            });

            // Options
            mainview.optionsMenuItem.setOnAction(e -> {
                if (!optionsStage.isShowing()) {
                    optionsStage.show();
                } else {
                    optionsStage.toFront();
                }
            });

            // Help button
            help.backbutton.setOnAction(e -> helpStage.hide());

            // Options button
            options.backbutton.setOnAction(e -> optionsStage.hide());

        } catch (Exception ex) {
            Logger.getLogger(WaterSimApp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
