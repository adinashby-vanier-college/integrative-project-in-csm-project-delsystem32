package edu.vanier.fluidSimulator.ui;

import edu.vanier.fluidSimulator.model.Particle;
import edu.vanier.fluidSimulator.model.Particle.LiquidType;
import edu.vanier.fluidSimulator.model.SimulationObject.SimulationObjectType;
import edu.vanier.fluidSimulator.model.SimulationObject;
import edu.vanier.fluidSimulator.physics.SpatialGrid;
import javafx.animation.AnimationTimer;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import java.util.ArrayList;
import java.util.List;

public class MainSceneView extends Pane {

    BorderPane bp = new BorderPane();

    MenuBar menuBar = new MenuBar();
    Menu fileMenu = new Menu("File");
    MenuItem logoutMenuItem = new MenuItem("Log out");
    MenuItem helpMenuItem = new MenuItem("Help");
    MenuItem exitMenuItem = new MenuItem("Exit Application");

    Menu liquidMenu = new Menu("Liquid");
    MenuItem waterchoice = new MenuItem("Water");
    MenuItem oilchoice = new MenuItem("Oil");
    MenuItem honeychoice = new MenuItem("Honey");

    Menu objectMenu = new Menu("Object");
    MenuItem woodchoice = new MenuItem("Wood");
    MenuItem brickchoice = new MenuItem("Brick");
    MenuItem steelchoice = new MenuItem("Steel");

    Menu moreMenu = new Menu("More");
    MenuItem optionsMenuItem = new MenuItem("Options");

    VBox propertiesBox = new VBox(10);
    Label propertiesLabel = new Label("Object Properties");
    Label massLabel = new Label("Mass (g):");
    Slider massSlider = new Slider(1, 10, 5.5);
    Label volumeLabel = new Label("Volume (cm³):");
    Slider volumeSlider = new Slider(1, 10, 5.5);

    VBox densityBox = new VBox(10);
    Label fluidDensityLabel = new Label("Fluid Density");
    TextField fluiddensitydisplay = new TextField();
    Label objectDensityLabel = new Label("Object Density");
    TextField objectdensitydisplay = new TextField();

    HBox forcesBox = new HBox(30);
    Label forcesLabel = new Label("Forces:");
    CheckBox gravityCheckBox = new CheckBox("Gravity");
    CheckBox typeForceCheckBox = new CheckBox("Type Interaction");
    CheckBox forceValuesCheckBox = new CheckBox("Force Values");

    VBox rightPanel = new VBox(10, propertiesBox, densityBox);

    Pane particleContainer = new Pane();
    private SimulationObject simulationObject;
    private final List<Particle> particles = new ArrayList<>();
    private boolean spawning = false;

    private LiquidType currentLiquidType = LiquidType.WATER;
    private Color currentLiquidColor = Color.BLUE;

    private SimulationObjectType currentSimulationObjectType = SimulationObjectType.CUSTOM;
    private final Color currentSimulationObjectColor = Color.BLACK;
    private Double lastObjectX = null;
    private Double lastObjectY = null;

    private boolean isObjectDragging = false;
    private double dragStartX;
    private double dragStartY;
    private double prevTranslateX;
    private double prevTranslateY;



    public MainSceneView() {
        setupUI();
        initializeSimulationObject();
        setupLiquidSelection();
        setupObjectSelection();
        setupMouseEvents();
        startAnimationLoop();
    }

    private void setupUI() {
        bp.setPrefSize(950, 650);

        fileMenu.getItems().addAll(logoutMenuItem, helpMenuItem, exitMenuItem);
        liquidMenu.getItems().addAll(waterchoice, oilchoice, honeychoice);
        objectMenu.getItems().addAll(woodchoice, brickchoice, steelchoice);
        moreMenu.getItems().add(optionsMenuItem);
        menuBar.getMenus().addAll(fileMenu, liquidMenu, objectMenu, moreMenu);

        propertiesBox.setPadding(new Insets(30));
        propertiesBox.setStyle("-fx-border-color: black; -fx-border-width: 1px;");
        propertiesLabel.setFont(Font.font(14));
        propertiesLabel.setStyle("-fx-font-weight: bold;");
        massSlider.setShowTickMarks(true);
        massSlider.setShowTickLabels(true);
        massSlider.setMajorTickUnit(10);
        massSlider.setMinorTickCount(10);
        massSlider.setSnapToTicks(true);
        volumeSlider.setShowTickMarks(true);
        volumeSlider.setShowTickLabels(true);
        volumeSlider.setMajorTickUnit(10);
        volumeSlider.setMinorTickCount(10);
        volumeSlider.setSnapToTicks(true);
        objectdensitydisplay.setDisable(true);
        setUpMassSlider();
        setUpVolumeSlider();
        propertiesBox.getChildren().addAll(propertiesLabel, massLabel, massSlider, volumeLabel, volumeSlider);

        densityBox.setPadding(new Insets(40));
        densityBox.setStyle("-fx-border-color: black; -fx-border-width: 1px;");
        fluidDensityLabel.setFont(Font.font(14));
        densityBox.getChildren().addAll(fluidDensityLabel, fluiddensitydisplay);
        objectDensityLabel.setFont(Font.font(14));
        densityBox.getChildren().addAll(objectDensityLabel, objectdensitydisplay);

        forcesBox.setMinHeight(150);
        forcesBox.setPadding(new Insets(25));
        forcesBox.setStyle("-fx-border-color: black; -fx-border-width: 1px;");
        forcesBox.setAlignment(Pos.CENTER_LEFT);
        forcesBox.getChildren().addAll(forcesLabel, gravityCheckBox, typeForceCheckBox, forceValuesCheckBox);

        rightPanel.setPrefWidth(200);

        particleContainer.setStyle("-fx-background-color: #f0f8ff; -fx-border-color: black; -fx-border-width: 1px;");
        particleContainer.setPrefSize(750, 650);

        bp.setTop(menuBar);
        bp.setRight(rightPanel);
        bp.setBottom(forcesBox);
        bp.setCenter(particleContainer);

        exitMenuItem.setOnAction(actionEvent -> Platform.exit());

        this.getChildren().add(bp);
    }

    private void setupLiquidSelection() {
        waterchoice.setOnAction(e -> {
            currentLiquidType = LiquidType.WATER;
            currentLiquidColor = Color.BLUE;
            fluiddensitydisplay.setText("1.0");
        });

        oilchoice.setOnAction(e -> {
            currentLiquidType = LiquidType.OIL;
            currentLiquidColor = Color.YELLOW;
            fluiddensitydisplay.setText("0.8");
        });

        honeychoice.setOnAction(e -> {
            currentLiquidType = LiquidType.HONEY;
            currentLiquidColor = Color.ORANGE;
            fluiddensitydisplay.setText("1.4");
        });
    }

    private void setupObjectSelection() {
        woodchoice.setOnAction(e -> updateObjectType(SimulationObjectType.WOOD));
        brickchoice.setOnAction(e -> updateObjectType(SimulationObjectType.BRICK));
        steelchoice.setOnAction(e -> updateObjectType(SimulationObjectType.STEEL));
    }

    private void setupMouseEvents() {
        particleContainer.setOnMousePressed(event -> {
            if (isObjectDragging) return;
            if (event.getButton() == MouseButton.PRIMARY) {
                spawning = true;
                spawnParticle(event.getX(), event.getY());
            } else if (event.getButton() == MouseButton.SECONDARY) {
                removeParticle(event.getX(), event.getY());
            }
        });

        particleContainer.setOnMouseReleased(event -> {
            if (isObjectDragging) return;
            if (event.getButton() == MouseButton.PRIMARY) {
                spawning = false;
            }
        });

        particleContainer.setOnMouseDragged(event -> {
            if (event.getButton() == MouseButton.PRIMARY && spawning) {
                spawnParticle(event.getX(), event.getY());
            } else if (event.getButton() == MouseButton.SECONDARY) {
                removeParticle(event.getX(), event.getY());
            }
        });

        simulationObject.setOnMousePressed(this::handleObjectPressed);
        simulationObject.setOnMouseDragged(this::handleObjectDragged);
        simulationObject.setOnMouseReleased(this::handleObjectReleased);
    }

    private void handleObjectPressed(MouseEvent event) {
        isObjectDragging = true;
        dragStartX = event.getSceneX();
        dragStartY = event.getSceneY();
        prevTranslateX = simulationObject.getTranslateX();
        prevTranslateY = simulationObject.getTranslateY();

        simulationObject.setVelocity(0, 0);
    }

    private void handleObjectDragged(MouseEvent event) {
        if (isObjectDragging) {
            double deltaX = event.getSceneX() - dragStartX;
            double deltaY = event.getSceneY() - dragStartY;
            simulationObject.setTranslateX(prevTranslateX + deltaX);
            simulationObject.setTranslateY(prevTranslateY + deltaY);
        }
    }

    private void handleObjectReleased(MouseEvent event) {
        isObjectDragging = false;
        simulationObject.resetForces();
    }


    private void removeParticle(double x, double y) {
        Particle toRemove = null;
        for (Particle particle : particles) {
            double dx = (particle.getLayoutX() + particle.getTranslateX()) - x;
            double dy = (particle.getLayoutY() + particle.getTranslateY()) - y;
            double distance = Math.hypot(dx, dy);
            if (distance <= particle.getRadius()) {
                toRemove = particle;
                break;
            }
        }
        if (toRemove != null) {
            particles.remove(toRemove);
            particleContainer.getChildren().remove(toRemove);
        }
    }

    private void spawnParticle(double x, double y) {
        int brushRadius = 15;
        int spacing = 8;

        for (int dx = -brushRadius; dx <= brushRadius; dx += spacing) {
            for (int dy = -brushRadius; dy <= brushRadius; dy += spacing) {
                if (dx * dx + dy * dy <= brushRadius * brushRadius) {
                    double spawnX = x + dx;
                    double spawnY = y + dy;
                    if (spawnX >= 0 && spawnY >= 0 && spawnX < particleContainer.getWidth() && spawnY < particleContainer.getHeight()) {
                        Particle particle = new Particle(spawnX, spawnY, 6, currentLiquidType, currentLiquidColor);
                        particles.add(particle);
                        particleContainer.getChildren().add(particle);
                    }
                }
            }
        }
        simulationObject.toFront();
    }


    private void initializeSimulationObject() {
        simulationObject = new SimulationObject(
                particleContainer,
                5.5,
                5.5,
                currentSimulationObjectType,
                currentSimulationObjectColor
        );
        particleContainer.getChildren().add(simulationObject);
        updateObjectDensity();

        massSlider.setValue(simulationObject.getMass());
        volumeSlider.setValue(simulationObject.getVolume());
    }

    private void startAnimationLoop() {
        new AnimationTimer() {
            private long lastTime = 0;
            @Override
            public void handle(long now) {
                if (lastTime == 0) {
                    lastTime = now;
                    return;
                }
                double deltaTime = (now - lastTime) / 1_000_000_000.0;
                lastTime = now;

                double currentObjectX = simulationObject.getLayoutX() + simulationObject.getTranslateX();
                double currentObjectY = simulationObject.getLayoutY() + simulationObject.getTranslateY();
                double objectVelocityX = 0;
                double objectVelocityY = 0;

                if (lastObjectX != null && lastObjectY != null && deltaTime > 0) {
                    if (!simulationObject.getIsCollisionX()) {
                        objectVelocityX = (currentObjectX - lastObjectX) / deltaTime;
                    }
                    if (!simulationObject.getIsCollisionY()) {
                        objectVelocityY = (currentObjectY - lastObjectY) / deltaTime;
                    }
                }

                lastObjectX = currentObjectX;
                lastObjectY = currentObjectY;


                if (Math.abs(objectVelocityX) > 0.1 || Math.abs(objectVelocityY) > 0.1) {
                    double influenceRadius = 100 * simulationObject.getWidth()/100;
                    double influenceStrength = 0.01;


                    for (Particle particle : particles) {
                        double particleX = particle.getLayoutX() + particle.getTranslateX();
                        double particleY = particle.getLayoutY() + particle.getTranslateY();
                        double dx = particleX - currentObjectX;
                        double dy = particleY - currentObjectY;
                        double distance = Math.hypot(dx, dy);

                        if (distance < influenceRadius) {
                            double falloff = (influenceRadius - distance) / influenceRadius;
                            double forceX = objectVelocityX * influenceStrength * falloff * deltaTime * simulationObject.getMass();
                            double forceY = objectVelocityY * influenceStrength * falloff * deltaTime * simulationObject.getMass();
                            particle.addVelocity(forceX, forceY);
                        }
                    }
                }




                double width = particleContainer.getWidth();
                double height = particleContainer.getHeight();
                SpatialGrid grid = new SpatialGrid(width, height, 20);
                grid.clear();
                for (Particle particle : particles) {
                    grid.add(particle);
                }

                if (gravityCheckBox.isSelected()) {
                    simulationObject.applyGravity();
                    simulationObject.applyBuoyancy(calculateWaterLevel(100), particles);
                    for (Particle particle : particles) {
                        particle.applyGravity();
                    }
                }

                for (Particle particle : particles) {
                    particle.checkWallCollisions(width, height);
                }

                double viscosityFactor = 0.05;
                for (Particle particle : particles) {
                    List<Particle> neighbors = grid.getNeighbors(particle);
                    double avgVX = 0, avgVY = 0;
                    int count = 0;
                    for (Particle neighbor : neighbors) {
                        if (neighbor != particle) {
                            avgVX += neighbor.getVelocityX();
                            avgVY += neighbor.getVelocityY();
                            count++;
                        }
                    }
                    if (count > 0) {
                        avgVX /= count;
                        avgVY /= count;
                        particle.addVelocity((avgVX - particle.getVelocityX()) * viscosityFactor,
                                (avgVY - particle.getVelocityY()) * viscosityFactor);
                    }
                }

                double repulsionFactor = 0.1;
                for (Particle particle : particles) {
                    List<Particle> neighbors = grid.getNeighbors(particle);
                    for (Particle neighbor : neighbors) {
                        if (neighbor != particle) {
                            if (System.identityHashCode(particle) < System.identityHashCode(neighbor)) {
                                double dx = (neighbor.getLayoutX() + neighbor.getTranslateX()) -
                                        (particle.getLayoutX() + particle.getTranslateX());
                                double dy = (neighbor.getLayoutY() + neighbor.getTranslateY()) -
                                        (particle.getLayoutY() + particle.getTranslateY());
                                double distance = Math.hypot(dx, dy);
                                double minDistance = particle.getRadius() + neighbor.getRadius();
                                if (distance < minDistance && distance > 0) {
                                    double overlap = minDistance - distance;
                                    double forceX = (overlap * repulsionFactor) * (dx / distance);
                                    double forceY = (overlap * repulsionFactor) * (dy / distance);
                                    particle.addVelocity(-forceX, -forceY);
                                    neighbor.addVelocity(forceX, forceY);
                                }
                            }
                        }
                    }
                }

                // interactions of different liquids
                if (typeForceCheckBox.isSelected()) {
                    double typeForce = 0.05;
                    for (Particle particle : particles) {
                        List<Particle> neighbors = grid.getNeighbors(particle);
                        for (Particle neighbor : neighbors) {
                            if (neighbor != particle && areTouching(particle, neighbor)) {
                                if (System.identityHashCode(particle) < System.identityHashCode(neighbor)) {
                                    LiquidType typeA = particle.getLiquidType();
                                    LiquidType typeB = neighbor.getLiquidType();
                                    //oil and water interaction
                                    if ((typeA == LiquidType.OIL && typeB == LiquidType.WATER) ||
                                            (typeA == LiquidType.WATER && typeB == LiquidType.OIL)) {
                                        if (typeA == LiquidType.OIL) {
                                            particle.addVelocity(0, -typeForce);
                                            neighbor.addVelocity(0, typeForce);
                                        } else {
                                            neighbor.addVelocity(0, -typeForce);
                                            particle.addVelocity(0, typeForce);
                                        }
                                    }
                                    //water and honey interaction
                                    else if ((typeA == LiquidType.WATER && typeB == LiquidType.HONEY) ||
                                            (typeA == LiquidType.HONEY && typeB == LiquidType.WATER)) {
                                        if (typeA == LiquidType.WATER) {
                                            particle.addVelocity(0, -typeForce);
                                            neighbor.addVelocity(0, typeForce);
                                        } else {
                                            neighbor.addVelocity(0, -typeForce);
                                            particle.addVelocity(0, typeForce);
                                        }
                                    }
                                    //oil and honey interaction
                                    else if ((typeA == LiquidType.OIL && typeB == LiquidType.HONEY) ||
                                            (typeA == LiquidType.HONEY && typeB == LiquidType.OIL)) {
                                        double dx = (neighbor.getLayoutX() + neighbor.getTranslateX()) -
                                                (particle.getLayoutX() + particle.getTranslateX());
                                        double dy = (neighbor.getLayoutY() + neighbor.getTranslateY()) -
                                                (particle.getLayoutY() + particle.getTranslateY());
                                        double distance = Math.hypot(dx, dy);
                                        if (distance > 0) {
                                            double forceX = (dx / distance) * typeForce;
                                            double forceY = (dy / distance) * typeForce;
                                            particle.addVelocity(-forceX, -forceY);
                                            neighbor.addVelocity(forceX, forceY);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                for (Particle particle : particles) {
                    List<Particle> neighbors = grid.getNeighbors(particle);
                    double sumX = 0;
                    double sumY = 0;
                    int count = 0;
                    for (Particle neighbor : neighbors) {
                        if (neighbor != particle) {
                            sumX += neighbor.getLayoutX() + neighbor.getTranslateX();
                            sumY += neighbor.getLayoutY() + neighbor.getTranslateY();
                            count++;
                        }
                    }
                    if (count > 0) {
                        double avgX = sumX / count;
                        double avgY = sumY / count;
                        double cohesionFactor = 0.005;
                        particle.applyCohesion(avgX, avgY, cohesionFactor);
                    }
                }


                for (Particle particle : particles) {
                    particle.updatePosition();
                }


                if (!isObjectDragging) {
                    simulationObject.updatePhysics(deltaTime);
                    simulationObject.updatePosition();
                }
                simulationObject.handleWallCollisions(isObjectDragging);
            }
        }.start();
    }

     //method to determine if two particles are touching.
    private boolean areTouching(Particle p, Particle q) {
        double dx = (p.getLayoutX() + p.getTranslateX()) - (q.getLayoutX() + q.getTranslateX());
        double dy = (p.getLayoutY() + p.getTranslateY()) - (q.getLayoutY() + q.getTranslateY());
        double distance = Math.hypot(dx, dy);
        return distance < (p.getRadius() + q.getRadius());
    }

    private void setUpMassSlider() {
        massSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            simulationObject.setMass(newVal.doubleValue());
            simulationObject.setFill(Color.BLACK);
            updateObjectDensity();
        });
        if (simulationObject != null) {
            massSlider.setValue(simulationObject.getMass());
        }
    }


    private void setUpVolumeSlider() {
        volumeSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            double previousSize = simulationObject.getWidth();
            double newVolume = newVal.doubleValue();
            double newSize = Math.sqrt(newVolume) * 30;

            simulationObject.setVolume(newVolume);
            simulationObject.setSize(newSize);

            double delta = newSize - previousSize;
            simulationObject.setLayoutX(simulationObject.getLayoutX() - delta/2);
            simulationObject.setLayoutY(simulationObject.getLayoutY() - delta/2);
            simulationObject.setFill(Color.BLACK);
            updateObjectDensity();
        });

        if (simulationObject != null) {
            volumeSlider.setValue(simulationObject.getVolume());
        }
    }

    private void updateObjectDensity() {
        double density = simulationObject.getDensity();
        objectdensitydisplay.setText(String.format("%.2f", density));
    }


    private void updateObjectType(SimulationObjectType type) {
        currentSimulationObjectType = type;
        double targetDensity = type.getDensity();

        double targetMass = simulationObject.getVolume() * targetDensity;
        targetMass = Math.max(1, Math.min(10, targetMass));

        simulationObject.setMass(targetMass);
        massSlider.setValue(targetMass);
        simulationObject.setFill(type.getColor());
        updateObjectDensity();
    }

    public double calculateWaterLevel(int n) {
        double containerWidth = particleContainer.getWidth();
        if (containerWidth <= 0 || n <= 0 || particles.isEmpty()) {
            return 0.0;
        }
        double intervalWidth = containerWidth / n;
        double sumY = 0;

        for (int i = 0; i < n; i++) {
            double minX = i * intervalWidth;
            double maxX = minX + intervalWidth;

            Particle highestParticle = null;
            double minY = Double.MAX_VALUE;

            for (Particle particle : particles) {
                double x = particle.getLayoutX() + particle.getTranslateX();
                double y = particle.getLayoutY() + particle.getTranslateY();

                if (x >= minX && x < maxX && y < minY) {
                    minY = y;
                    highestParticle = particle;
                }
            }

            if (highestParticle != null) {
                sumY += minY;

            }
        }

        return particleContainer.getHeight() - (sumY / n);
    }

    public Pane getParticleContainer() {
        return particleContainer;
    }
}
