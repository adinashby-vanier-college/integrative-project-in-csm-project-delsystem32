package edu.vanier.fluidSimulator.model;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.List;

public class SimulationObject extends Rectangle {
    private double mass;
    private double volume;
    private double velocityX;
    private double velocityY;
    private double netForceX = 0;
    private double netForceY = 0;
    private double accelerationX = 0;
    private double accelerationY = 0;
    private static final double GRAVITY = 9.81;
    private final SimulationObjectType type;
    private final Pane parentPane;
    private static final double WALL_BOUNCE_FACTOR = 0.3;
    private static final double WALL_FRICTION = 0.9;
    private boolean isCollisionX = false, isCollisionY = false;

    public enum SimulationObjectType {
        BRICK(1.8, Color.MAROON),
        STEEL(7.85, Color.GRAY),
        WOOD(0.7, Color.SANDYBROWN),
        CUSTOM(1, Color.BLACK);

        private final double density;
        private final Color color;

        SimulationObjectType(double density, Color color) {
            this.density = density;
            this.color = color;
        }

        public double getDensity() {
            return density;
        }

        public Color getColor() {
            return color;
        }
    }
    public SimulationObject(Pane parentPane, double mass, double volume, SimulationObjectType type, Color color) {
        super(Math.sqrt(volume) * 30, Math.sqrt(volume) * 30);
        this.volume = volume;
        this.mass = mass;
        this.type = type;
        this.parentPane = parentPane;
        this.setFill(color);
        parentPane.widthProperty().addListener((obs, oldVal, newVal) -> {
            setLayoutX((newVal.doubleValue() / 2) - Math.sqrt(volume)/2 * 30);
        });

        parentPane.heightProperty().addListener((obs, oldVal, newVal) -> {
            setLayoutY((newVal.doubleValue() / 2) - Math.sqrt(volume)/2 * 30);
        });

    }


    public void applyForce(double forceX, double forceY) {
        this.netForceX += forceX;
        this.netForceY += forceY;
    }

    public void applyGravity() {
        double gravitationalForce = this.mass * GRAVITY;
        applyForce(0, gravitationalForce);
    }

    public void applyBuoyancy(double waterLevel, List<Particle> particles) {
        if (!isObjectTouchingParticles(particles)) return;

        Particle.LiquidType liquidType = getTouchingLiquidType(particles);
        double liquidDensity = liquidType.getDensity();
        double dragCoefficient = liquidType.getDragCoefficient();
        double objectDensity = getDensity();

        if (parentPane.getHeight() - getCenterPositionY() < waterLevel) {
            double buoyancyForce = (liquidDensity / objectDensity) * mass * GRAVITY;
            applyForce(0, -buoyancyForce);
        }

        applyDragForce(dragCoefficient);
    }

    private void applyDragForce(double dragCoefficient) {
        double dragForce = velocityY * dragCoefficient;
        applyForce(0, -dragForce);
    }

    public void updatePhysics(double deltaTime) {
        this.accelerationX = netForceX / mass;
        this.accelerationY = netForceY / mass;

        this.velocityX += accelerationX * deltaTime;
        this.velocityY += accelerationY * deltaTime;
        resetForces();
    }

    public void handleWallCollisions(boolean isDragging) {
        if (parentPane.getWidth() <= 0 || parentPane.getHeight() <= 0) {
            return;
        }
        isCollisionX = false;
        isCollisionY = false;

        double containerWidth = parentPane.getWidth();
        double containerHeight = parentPane.getHeight();

        double currentX = getLayoutX() + getTranslateX();
        double currentY = getLayoutY() + getTranslateY();
        double width = getWidth();
        double height = getHeight();

        //right wall collision
        if (currentX + width >= containerWidth) {
            isCollisionX = true;
            double overlap = (currentX + width) - containerWidth;
            setTranslateX(getTranslateX() - overlap);
            if (!isDragging) {
                velocityX *= -WALL_BOUNCE_FACTOR;
            }
        }

        //left wall collision
        if (currentX <= 0) {
            isCollisionX = true;
            setTranslateX(getTranslateX() - currentX);
            if (!isDragging) {
                velocityX *= -WALL_BOUNCE_FACTOR;
            }
        }

        //floor collision
        if (currentY + height >= containerHeight) {
            isCollisionY = true;
            double overlap = (currentY + height) - containerHeight;
            setTranslateY(getTranslateY() - overlap);
            if (!isDragging) {
                velocityY *= -WALL_BOUNCE_FACTOR;
                velocityX *= WALL_FRICTION;
            }
        }

        //ceiling collision
        if (currentY <= 0) {
            isCollisionY = true;
            setTranslateY(getTranslateY() - currentY);
            if (!isDragging) {
                velocityY *= -WALL_BOUNCE_FACTOR;
                velocityX *= WALL_FRICTION;
            }
        }
    }

    public boolean isParticleTouchingObject(Particle particle) {
        double objX = getLayoutX() + getTranslateX();
        double objY = getLayoutY() + getTranslateY();
        double objWidth = getWidth();
        double objHeight = getHeight();

        double particleX = particle.getLayoutX() + particle.getTranslateX();
        double particleY = particle.getLayoutY() + particle.getTranslateY();

        return particleX >= objX && particleX <= objX + objWidth && particleY >= objY && particleY <= objY + objHeight;
    }

    public boolean isObjectTouchingParticles(List<Particle> particles) {
        boolean isTouching = false;
        for (Particle particle : particles) {
            double objX = getLayoutX() + getTranslateX();
            double objY = getLayoutY() + getTranslateY();
            double objWidth = getWidth();
            double objHeight = getHeight();

            double particleX = particle.getLayoutX() + particle.getTranslateX();
            double particleY = particle.getLayoutY() + particle.getTranslateY();

            if (particleX >= objX && particleX <= objX + objWidth && particleY >= objY && particleY <= objY + objHeight) {
                isTouching = true;
            }
        } return isTouching;
    }

    private Particle.LiquidType getTouchingLiquidType(List<Particle> particles) {
        int waterCount = 0;
        int oilCount = 0;
        int honeyCount = 0;

        for (Particle particle : particles) {
            if (isParticleTouchingObject(particle)) {
                switch (particle.getLiquidType()) {
                    case WATER -> waterCount++;
                    case OIL -> oilCount++;
                    case HONEY -> honeyCount++;
                }
            }
        }
        if (waterCount >= oilCount && waterCount >= honeyCount) {
            return Particle.LiquidType.WATER;
        } else if (oilCount >= waterCount && oilCount >= honeyCount) {
            return Particle.LiquidType.OIL;
        } else {
            return Particle.LiquidType.HONEY;
        }
    }

    public void resetForces() {
        this.netForceX = 0;
        this.netForceY = 0;
    }

    public double getMass() {
        return mass;
    }

    public double getVolume() {
        return volume;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    public void setVolume(double volume) {
        this.volume = volume;
    }

    public void setSize(double size) {
        setWidth(size);
        setHeight(size);
    }

    public void setVelocity(double x, double y) {
        this.velocityX = x;
        this.velocityY = y;
    }

    public boolean getIsCollisionX() {
        return isCollisionX;
    }

    public boolean getIsCollisionY() {
        return isCollisionY;
    }

    public void updatePosition() {
        setTranslateX(getTranslateX() + velocityX);
        setTranslateY(getTranslateY() + velocityY);
    }

    public double getCenterPositionY() {
        return getLayoutY() + getTranslateY() + getHeight() / 2;
    }

    public double getDensity() {
        return mass / volume;
    }
}
