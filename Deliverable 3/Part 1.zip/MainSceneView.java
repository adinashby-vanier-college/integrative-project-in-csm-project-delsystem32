/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package watersimapp;

import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

/**
 *
 * @author bdmmc
 */
public class MainSceneView extends Pane{
    
    BorderPane bp = new BorderPane();
    
    MenuBar menuBar = new MenuBar();
    
    Menu fileMenu = new Menu("File");
    MenuItem logoutMenuItem = new MenuItem("Log out");
    MenuItem helpMenuItem = new MenuItem("Help");
    MenuItem exitMenuItem = new MenuItem("Exit Application");
    
    Menu liquidMenu = new Menu("Liquid");
    MenuItem waterchoice = new MenuItem("Water");
    MenuItem oilchoice = new MenuItem("Oil");
    MenuItem honeychoice = new MenuItem("Honey");
    
    Menu objectMenu = new Menu("Object");
    MenuItem woodchoice = new MenuItem("Wood");
    MenuItem brickchoice = new MenuItem("Brick");
    MenuItem steelchoice = new MenuItem("Steel");
        
    Menu moreMenu = new Menu("More");
    MenuItem optionsMenuItem = new MenuItem("Options");
    
    VBox propertiesBox = new VBox(10);
    
    Label propertiesLabel = new Label("Object Properties");
    
    Label massLabel = new Label("Mass:");
    Slider massSlider = new Slider(0, 10, 5);
    
    Label volumeLabel = new Label("Volume:");
    Slider volumeSlider = new Slider(0, 10, 5);
    
    VBox DensityBox = new VBox(10);
    
    Label fluidDensityLabel = new Label("Fluid Density");
    TextField fluiddensitydisplay = new TextField();
    
    Label objectDensityLabel = new Label("Object Density");
    TextField objectdensitydisplay = new TextField();
    
    HBox forcesBox = new HBox(30);
    
    Label forcesLabel = new Label("Forces:");
    CheckBox gravityCheckBox = new CheckBox("Gravity");
    CheckBox buoyancyCheckBox = new CheckBox("Buoyancy");
    CheckBox forceValuesCheckBox = new CheckBox("Force Values");
    
    VBox rightPanel = new VBox(10, propertiesBox, DensityBox);
    
    MainSceneView() {
        
        bp.setPrefSize(950, 650);
        
        fileMenu.getItems().addAll(logoutMenuItem,
                helpMenuItem,
                exitMenuItem
        ); 
        
        liquidMenu.getItems().addAll(waterchoice,
                oilchoice,
                honeychoice
        );
        
        objectMenu.getItems().addAll(woodchoice,
                brickchoice,
                steelchoice
        );
        
        moreMenu.getItems().add(optionsMenuItem);
        
        menuBar.getMenus().addAll(fileMenu, liquidMenu, objectMenu, moreMenu);
        
        //Main layout
        bp.setTop(menuBar);
        
        //Object Properties section
        propertiesBox.setPadding(new Insets(30));
        propertiesBox.setStyle("-fx-border-color: black; -fx-border-width: 1px;");
        
        propertiesLabel.setFont(Font.font(14));
        propertiesLabel.setStyle("-fx-font-weight: bold;");

        massSlider.setShowTickMarks(true);
        massSlider.setShowTickLabels(true);
        massSlider.setMajorTickUnit(10);
        massSlider.setMinorTickCount(10);
        massSlider.setSnapToTicks(true);

        volumeSlider.setShowTickMarks(true);
        volumeSlider.setShowTickLabels(true);
        volumeSlider.setMajorTickUnit(10);
        volumeSlider.setMinorTickCount(10);
        volumeSlider.setSnapToTicks(true);

        propertiesBox.getChildren().addAll(propertiesLabel, massLabel, massSlider, volumeLabel, volumeSlider);

        //Density section
        DensityBox.setPadding(new Insets(40));
        DensityBox.setStyle("-fx-border-color: black; -fx-border-width: 1px;");
        
        
        fluidDensityLabel.setFont(Font.font(14));
        
        DensityBox.getChildren().addAll(fluidDensityLabel, fluiddensitydisplay);
        
        objectDensityLabel.setFont(Font.font(14));
        
        DensityBox.getChildren().addAll(objectDensityLabel, objectdensitydisplay);

        //Forces selection
        forcesBox.setMinHeight(150);
        forcesBox.setPadding(new Insets(25));
        forcesBox.setStyle("-fx-border-color: black; -fx-border-width: 1px;");
        forcesBox.setAlignment(Pos.CENTER_LEFT);
        forcesBox.getChildren().addAll(forcesLabel, gravityCheckBox, buoyancyCheckBox, forceValuesCheckBox);

        //Right panel layout
        
        rightPanel.setPrefWidth(200);
        
        //Main layout
        bp.setTop(menuBar);
        bp.setRight(rightPanel);
        bp.setBottom(forcesBox);
        
        //Exit menu item execution
        exitMenuItem.setOnAction(actionEvent -> Platform.exit());
        
        this.getChildren().add(bp);
    }
}
