/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package watersimapp;

import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 *
 * @author bdmmc
 */
public class WaterSimApp extends Application{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    @Override
    public void start(Stage stage) throws Exception {
        
        LoginView login = new LoginView();
        HelpView help = new HelpView();
        OptionsView options = new OptionsView();
        MainSceneView mainview = new MainSceneView();
        
        Scene scene = new Scene(mainview, 950,650);
        Scene firstscene = new Scene(login,400,220);
        
        stage.setResizable(false);
        stage.setTitle("Byuoncy Simulator");
        stage.setScene(firstscene);
        stage.show();
        
        //New menuitem execution
        mainview.logoutMenuItem.setOnAction(actionEvent -> {
            try {
                this.start(stage);
            } catch (Exception ex) {
                Logger.getLogger(WaterSimApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        
        //Help menu item execution
        Scene helpscene = new Scene(help,400,300);
        mainview.helpMenuItem.setOnAction(e->{stage.setScene(helpscene);});
        
        //Options menu execution
        Scene optionsscene = new Scene(options,700,400);
        mainview.optionsMenuItem.setOnAction(e->{stage.setScene(optionsscene);});
        
        //Login button execution
        login.loginbtn.setOnAction(e->{stage.setScene(scene);});
        
        //Back button execution
        help.backbutton.setOnAction(e->{stage.setScene(scene);});
        options.backbutton.setOnAction(e->{stage.setScene(scene);});
        
        
    }
    
}
