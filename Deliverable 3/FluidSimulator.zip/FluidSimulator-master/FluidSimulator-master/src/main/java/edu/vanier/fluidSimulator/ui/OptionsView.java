/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.vanier.fluidSimulator.ui;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;

/**
 *
 * @author bdmmc
 */
public class OptionsView extends Pane{
    
    Label title = new Label("Options"); 
    Label scheme = new Label("Colour Scheme: ");
    Button light = new Button("Light mode");
    Button dark = new Button("Dark mode");
    Label language = new Label("Language: ");
    
    ObservableList<String> languages = 
    FXCollections.observableArrayList(
        "English",
        "French",
        "Spanish"
    );
    
    ComboBox cb = new ComboBox(languages);
    Label fontsize = new Label("Font Size: ");
    Slider fontSlider = new Slider(0, 10, 5);
    Button backbutton = new Button("Back to main screen"); 
    
    
    OptionsView() {
        
        title.underlineProperty().set(true);
        title.setFont(new Font(20));
        
        scheme.underlineProperty().set(true);
        light.managedProperty().set(true);
        
        language.underlineProperty().set(true);
        
        cb.setValue("English");
        
        fontsize.underlineProperty().set(true);
        
        fontSlider.setShowTickMarks(true);
        fontSlider.setShowTickLabels(true);
        fontSlider.setMajorTickUnit(10);
        fontSlider.setMinorTickCount(10);
        fontSlider.setSnapToTicks(true);
        
        
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));
        
        grid.add(title, 0, 0, 2, 1);
        grid.add(scheme, 0, 1);
        grid.add(light, 1, 1);
        grid.add(dark, 2, 1);
        grid.add(language, 0, 3);
        grid.add(cb, 1, 3);
        grid.add(fontsize, 0, 5);
        grid.add(fontSlider, 1, 5);
        
        HBox hb = new HBox(10);
        hb.setAlignment(Pos.BOTTOM_RIGHT);
        hb.getChildren().add(backbutton);
        
        grid.add(hb, 23, 22);
        
        this.getChildren().add(grid);
        
    }
}
