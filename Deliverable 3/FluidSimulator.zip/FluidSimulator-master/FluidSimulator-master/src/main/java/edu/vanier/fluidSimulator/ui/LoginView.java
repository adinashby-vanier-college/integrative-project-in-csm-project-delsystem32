/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.vanier.fluidSimulator.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

/**
 *
 * @author bdmmc
 */
public class LoginView extends Pane{
    
    //Creating elements
    Label title = new Label("                Byuoncy Simulator\nBy: Brendon, Eric, Kamran, and Hamza");
    Text user = new Text("Username:");
    TextField userTextField = new TextField();
    Text pass = new Text("Password: ");
    TextField passTextField = new TextField();
    Button loginbtn = new Button("Login");
    
    LoginView(){
        //Creating GridPane
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));
        
        title.setFont(new Font(20));
        
        //Adding elements to the GridPane
        grid.add(title, 0, 0, 2, 1);
        grid.add(user, 0, 1);
        grid.add(userTextField, 1, 1);
        grid.add(pass, 0, 2);
        grid.add(passTextField, 1, 2);
        
        //Creating HBox
        HBox hb = new HBox(10);
        hb.setAlignment(Pos.BOTTOM_RIGHT);
        
        //Adding the button to the HBox
        hb.getChildren().add(loginbtn);
        
        //Adding the HBox to the GridPane
        grid.add(hb, 1, 4);
        
        //Message to pop up when the user does not have an account
        final Text noaccount = new Text();
        grid.add(noaccount, 1, 6);
        
        //Adding the GridPane to LoginView
        this.getChildren().addAll(grid);
    }

}
